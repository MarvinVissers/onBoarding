package com.example.onboardingbook;

        import androidx.appcompat.app.AppCompatActivity;

        import android.content.Intent;
        import android.net.Uri;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.ImageButton;
        import android.widget.ImageView;
//importeren functies

        import org.json.JSONArray;
        import org.json.JSONException;
        import org.json.JSONObject;
        import com.squareup.picasso.Picasso;
        import java.io.IOException;
        import java.net.HttpURLConnection;
        import java.net.URL;
        import java.util.Scanner;

public class BoekActivity extends AppCompatActivity {


    private JSONArray result;

    //methoden callen
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);

        String sUrl = "https://i.imgur.com/mZeT9sq.png";
        ImageView img = findViewById (R.id.StudyStore);
        Picasso.with (getBaseContext ()).load (sUrl).into (img);

        String dUrl = "https://i.imgur.com/YeRlUoo.png";
        ImageButton dimg = findViewById (R.id.BoekBtn);
        Picasso.with (getBaseContext ()).load (dUrl).into (dimg);
    }
    public void onBoekBtnClick(View view) throws IOException, JSONException, InterruptedException {
        String website = getOpleidingUrl(4);
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(website));
        startActivity(browserIntent);
    }

    //connectie maken met de JSON
    public String getOpleidingUrl(final int opleidingnr) throws IOException, JSONException, InterruptedException {
        final String[] inlineArray = {""};

        //thread omdat netwerk access niet in UI thread mag uitgevoerd worden
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    //openen van je url/api connectie
                    URL url = new URL("https://adaonboarding.ml/t4/GetBoekenOpleiding?opleiding=" + opleidingnr);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setRequestProperty("Accept", "application/json");
                    conn.connect();
                    int responseCode = conn.getResponseCode();
                    if (responseCode != 200) {
                        throw new RuntimeException("HttpResponseCode: " + responseCode);
                    } else  // Hier zet je je json in een string
                    {
                        Scanner sc = new Scanner(url.openStream());
                        String inline = "";
                        while (sc.hasNext()) {
                            inline += sc.nextLine();
                        }
                        sc.close();
                        inlineArray[0] = inline;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        //thread starten en wachten tot hij klaar is zodat json data gebruikt kan worden
        thread.start();
        thread.join();

        //json omzetten naar object en daar het juiste object uithalen(opleiding id)
        JSONObject jobj = new JSONObject(inlineArray[0]);
        JSONArray jsonarr_1 = (JSONArray) jobj.get("item");
        JSONObject jsonobj_1 = (JSONObject) jsonarr_1.get(0);
        String opleidingId = jsonobj_1.get("opleiding_id").toString();


        //switch zodat elke gebruiker iets anders ziet ... links nog geen return gegeven. Uitzoeken hoe dit moet
        switch (opleidingId) {
            case "1":
                return "https://www.studystore.nl/boekenlijst/Associate-degrees-Academie/2019/BL079169/Ad-Informatica-leerjaar-1";

            case "2":
                return "https://www.studystore.nl/boekenlijst/Associate-degrees-Academie/2019/BL079170/Ad-Accountancy-leerjaar-1";

            case "3":
                return ": https://www.studystore.nl/boekenlijst/Associate-degrees-Academie/2019/BL079174/Ad-Bedrijfskunde-leerjaar-1-";

            case "4":
                return "https://www.studystore.nl/boekenlijst/Associate-degrees-Academie/2019/BL088447/Built-Environment-leerjaar-1";
            case "5":
                return "https://www.studystore.nl/boekenlijst/Associate-degrees-Academie/2019/BL079173/Ad-Engineering-leerjaar-1";
            case "6":
                return "https://www.studystore.nl/";
            case "7":
                return "https://www.studystore.nl/boekenlijst/Associate-degrees-Academie/2019/BL079166/Ad-Human-Resource-Management-leerjaar-1";
            case "8":
                return "https://www.studystore.nl/boekenlijst/Associate-degrees-Academie/2019/BL079171/Ad-Logistiek-leerjaar-1";
            case "9":
                return "https://www.studystore.nl/boekenlijst/Associate-degrees-Academie/2019/BL079172/Ad-Management-leerjaar-1";
            default:
                return "https://www.google.nl";



                }
            }
        }
